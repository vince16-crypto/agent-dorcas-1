"""Render the channel profile picture and banner to PNG with headless Chromium."""
import base64, pathlib
from playwright.sync_api import sync_playwright

HERE = pathlib.Path(__file__).parent
FONT = "data:font/ttf;base64," + base64.b64encode((HERE.parent / "assets/fonts/Poppins-Bold.ttf").read_bytes()).decode()
NIA = "data:image/svg+xml;base64," + base64.b64encode((HERE / "nia.svg").read_bytes()).decode()

NOTES = "".join(
    f'<div class="note" style="left:{x}%;top:{y}%;font-size:{s}px;transform:rotate({r}deg);color:{c}">{g}</div>'
    for x, y, s, r, c, g in [
        (6, 12, 120, -12, "#FFD23F", "&#9835;"), (15, 70, 90, 10, "#2EC4B6", "&#9834;"),
        (88, 16, 110, 14, "#FF6B3D", "&#9836;"), (80, 72, 100, -8, "#FFD23F", "&#9835;"),
        (30, 8, 70, 6, "#FFFFFF", "&#9834;"), (66, 82, 70, -14, "#FFFFFF", "&#9835;"),
    ])

BASE_CSS = f"""
@font-face {{ font-family: P; src: url('{FONT}'); font-weight: 100 900; }}
* {{ margin:0; padding:0; box-sizing:border-box; }}
body {{ font-family: P, sans-serif; overflow:hidden; }}
.note {{ position:absolute; font-family: DejaVu Sans, sans-serif; opacity:.9; }}
"""

PROFILE = f"""<html><head><style>{BASE_CSS}
body {{ width:800px; height:800px; background:radial-gradient(circle at 50% 42%, #7B3FB0 0%, #4A1F73 70%); position:relative; }}
.ring {{ position:absolute; inset:34px; border-radius:50%; border:22px dashed #FFD23F; opacity:.35; }}
img {{ position:absolute; left:90px; top:118px; width:620px; }}
</style></head><body><div class="ring"></div><img src="{NIA}"></body></html>"""

# YouTube banner: 2560x1440; text-and-logo safe area is the centered 1546x423.
BANNER = f"""<html><head><style>{BASE_CSS}
body {{ width:2560px; height:1440px; position:relative;
  background: linear-gradient(120deg, #4A1F73 0%, #7B3FB0 45%, #FF6B3D 100%); }}
.stripes {{ position:absolute; inset:0; background: repeating-linear-gradient(-45deg, rgba(255,255,255,.05) 0 40px, transparent 40px 80px); }}
.safe {{ position:absolute; left:507px; top:508px; width:1546px; height:423px; display:flex; align-items:center; gap:48px; }}
.safe img {{ height:410px; }}
h1 {{ color:#FFFFFF; font-size:108px; line-height:1; letter-spacing:-2px; text-shadow: 0 8px 0 #2B0F45; }}
h1 span {{ color:#FFD23F; }}
p {{ font-weight:700; color:#FFFFFF; font-size:42px; margin-top:14px; }}
.pill {{ font-weight:700; display:inline-block; background:#2EC4B6; color:#10302D; font-size:34px; padding:8px 28px; border-radius:60px; margin-top:16px; }}
</style></head><body><div class="stripes"></div>{NOTES}
<div class="safe"><img src="{NIA}"><div>
<h1>Nia's <span>Rhythm</span> Room</h1>
<p>Sing, dance &amp; learn with Nia!</p>
<div class="pill">New songs every Mon &bull; Wed &bull; Fri</div>
</div></div></body></html>"""


def render(html: str, w: int, h: int, out: pathlib.Path) -> None:
    with sync_playwright() as p:
        b = p.chromium.launch()
        pg = b.new_page(viewport={"width": w, "height": h})
        pg.set_content(html)
        pg.wait_for_timeout(400)
        pg.screenshot(path=str(out))
        b.close()


if __name__ == "__main__":
    render(PROFILE, 800, 800, HERE / "profile.png")
    render(BANNER, 2560, 1440, HERE / "banner.png")
    print("ok")
